#!/usr/bin/env bash
set -euo pipefail

# Purpose:
# Allow a Service Principal / Managed Identity group to use Fabric APIs.
# Requires Fabric admin permissions and Fabric CLI `fab` installed and authenticated.
# Review before running in a real tenant.

GROUP_OBJECT_ID="${1:-}"
GROUP_NAME="${2:-Microsoft Fabric Workload Identities}"

if [[ -z "$GROUP_OBJECT_ID" ]]; then
  echo "Usage: $0 <entra-group-object-id> [group-name]"
  exit 1
fi

BODY=$(jq -nc --arg oid "$GROUP_OBJECT_ID" --arg name "$GROUP_NAME" \
  '{enabled:true,canSpecifySecurityGroups:true,enabledSecurityGroups:[{graphId:$oid,name:$name}]}')

fab api --method post admin/tenantsettings/ServicePrincipalAccessGlobalAPIs/update -i "$BODY"
fab api --method post admin/tenantsettings/ServicePrincipalAccessPermissionAPIs/update -i "$BODY"
fab api --method post admin/tenantsettings/AllowServicePrincipalsCreateAndUseProfiles/update -i "$BODY"

echo "Fabric tenant settings updated for group: $GROUP_NAME ($GROUP_OBJECT_ID)"
