#!/usr/bin/env bash
set -euo pipefail

ENVIRONMENT="${1:-dev}"
BACKEND_RG="${TF_BACKEND_RG:-rg-tfstate-fabric-frc}"
BACKEND_STORAGE="${TF_BACKEND_STORAGE:-sttfstatefabric001}"
BACKEND_CONTAINER="${TF_BACKEND_CONTAINER:-tfstate}"

cd "$(dirname "$0")/../environments/${ENVIRONMENT}"

terraform init \
  -backend-config="resource_group_name=${BACKEND_RG}" \
  -backend-config="storage_account_name=${BACKEND_STORAGE}" \
  -backend-config="container_name=${BACKEND_CONTAINER}" \
  -backend-config="key=fabric-platform-${ENVIRONMENT}.tfstate"

terraform fmt -recursive
terraform validate
terraform plan -out=tfplan
