# Variables principales

| Variable | Description |
|---|---|
| `subscription_id` | Subscription Azure cible |
| `tenant_id` | Tenant Microsoft Entra ID |
| `project_code` | Code court du projet, ex. `mdm` |
| `environment` | `dev`, `tst`, `prod` |
| `terraform_principal_object_id` | Object ID de l'identité Azure DevOps/Terraform |
| `create_entra_groups` | Crée les groupes Entra si `true` |
| `existing_entra_group_object_ids` | Utilise des groupes existants si besoin |
| `fabric_capacity_sku_name` | SKU Fabric F2/F4/F8/F16... |
| `fabric_capacity_admin_members` | Admins de la capacité Fabric |
| `enable_fabric_git_integration` | Active Git integration Fabric |
| `fabric_git_connection_id` | Connection ID Fabric/Azure DevOps |
| `create_azure_devops_project` | Crée un projet Azure DevOps avec Terraform |
