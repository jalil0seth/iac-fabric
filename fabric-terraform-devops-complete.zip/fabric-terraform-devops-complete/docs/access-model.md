# Modèle d'accès

## Groupes Entra ID

Le projet crée ou réutilise quatre groupes :

| Groupe logique | Rôle |
|---|---|
| `fabric_admins` | Admin Fabric workspace, Key Vault admin, Storage Blob Data Owner |
| `data_engineers` | Contributor Fabric workspace, Storage Blob Data Contributor |
| `data_readers` | Viewer Fabric workspace, Storage Blob Data Reader |
| `devops_agents` | Identités CI/CD, Admin Fabric workspace, Storage Blob Data Owner, Key Vault admin |

## Pourquoi passer par des groupes ?

C'est plus propre que d'assigner directement des utilisateurs :

- moins de changements Terraform quand les équipes changent ;
- gouvernance claire ;
- audit plus simple ;
- séparation entre rôles humains et rôles CI/CD.

## Service principal Azure DevOps / Terraform

Le service principal ou l'identité managée utilisé par le pipeline doit avoir :

1. Droits Azure suffisants pour créer les ressources et RBAC.
2. Autorisation Fabric tenant pour utiliser les APIs Fabric.
3. Rôle Fabric workspace Admin via groupe `devops_agents`.
4. Accès Azure DevOps repo si Git integration est activée.

## RBAC Azure sur ADLS2

- Admins et DevOps : `Storage Blob Data Owner`
- Engineers : `Storage Blob Data Contributor`
- Readers : `Storage Blob Data Reader`

## Rôles Fabric Workspace

- Admins : `Admin`
- Engineers : `Contributor`
- Readers : `Viewer`
- DevOps agents : `Admin`
