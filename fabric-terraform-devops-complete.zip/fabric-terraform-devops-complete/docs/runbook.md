# Runbook d'exécution

## 1. Préparer le principal CI/CD

Créer ou réutiliser un service principal / managed identity pour Azure DevOps.

Il doit pouvoir :

- créer/modifier des ressources Azure ;
- créer des role assignments Azure ;
- appeler les APIs Fabric ;
- créer ou modifier les groupes Entra si `create_entra_groups = true`.

## 2. Autoriser le principal côté Fabric

Dans Fabric Admin Portal, activer les tenant settings nécessaires pour les Service Principals / Managed Identities. Tu peux aussi utiliser le script :

```bash
./scripts/setup-fabric-tenant-settings.sh <group-object-id> "Microsoft Fabric Workload Identities"
```

## 3. Créer le backend Terraform

```bash
cd backend
cp terraform.tfvars.example terraform.tfvars
terraform init
terraform apply
```

## 4. Déployer DEV

```bash
cd environments/dev
cp terraform.tfvars.example terraform.tfvars
terraform init \
  -backend-config="resource_group_name=rg-tfstate-fabric-frc" \
  -backend-config="storage_account_name=sttfstatefabric001" \
  -backend-config="container_name=tfstate" \
  -backend-config="key=fabric-platform-dev.tfstate"
terraform plan -out tfplan
terraform apply tfplan
```

## 5. Déployer TEST puis PROD

Même logique :

```bash
cd environments/tst
terraform init ... key=fabric-platform-tst.tfstate
terraform apply

cd environments/prod
terraform init ... key=fabric-platform-prod.tfstate
terraform apply
```

## 6. Activer Git Fabric plus tard

Ne pas activer Git integration au premier apply. D'abord vérifier :

- workspace créé ;
- capacité assignée ;
- groupes assignés ;
- service principal autorisé ;
- repo Azure DevOps existe ;
- configured connection Fabric/Azure DevOps existe.

Puis modifier :

```hcl
enable_fabric_git_integration = true
fabric_git_connection_id      = "<connection-id>"
```

## 7. Erreurs fréquentes

### Principal non autorisé dans Fabric

Symptôme : le provider Fabric échoue lors de la lecture/création workspace.

Correction : vérifier les tenant settings Fabric et l'appartenance du principal au groupe autorisé.

### Propagation Entra ID lente

Symptôme : role assignment échoue juste après création groupe.

Correction : relancer `terraform apply` après quelques minutes.

### Capacity non trouvée côté Fabric

Symptôme : data source `fabric_capacity` ne trouve pas la capacité juste après création AzureRM.

Correction : le module ajoute déjà un `time_sleep`. Augmenter la durée si besoin.

### Git integration échoue

Symptôme : erreur connection mismatch / principal type / feature not available.

Correction : valider la Fabric configured connection, les droits Azure DevOps du principal, puis relancer.
