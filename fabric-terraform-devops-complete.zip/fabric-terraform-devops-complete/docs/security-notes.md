# Notes sécurité

## Production

Pour la production, il est recommandé de :

- activer `enable_purge_protection = true` pour Key Vault ;
- désactiver l'accès public et ajouter Private Endpoints ;
- utiliser Workload Identity Federation plutôt qu'un client secret ;
- stocker le state Terraform dans un storage dédié avec accès restreint ;
- éviter les PAT Azure DevOps longs ;
- utiliser des groupes Entra ID, pas des utilisateurs directs ;
- ne jamais commiter `terraform.tfvars`.

## Ce que le projet ne force pas volontairement

Le projet laisse `public_network_access_enabled = true` par défaut pour faciliter un premier POC. Pour un vrai environnement client, passe-le à `false` et ajoute des modules Private Endpoint / DNS.
