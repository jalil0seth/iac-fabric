# Décision : utiliser Terraform uniquement

## Pourquoi Terraform plutôt que Bicep ici ?

Bicep est excellent pour les ressources Azure ARM : resource group, storage account, Key Vault, RBAC, Fabric Capacity. Mais dès qu'on veut automatiser Microsoft Fabric Workspace, les rôles workspace, Git integration et des objets Fabric, on sort rapidement du périmètre Azure Resource Manager.

Terraform est plus adapté dans ce contexte parce qu'il peut combiner plusieurs providers dans un seul état :

- `azurerm` pour Azure Resource Group, ADLS2, Key Vault, Fabric Capacity
- `azuread` pour Entra ID groups
- `fabric` pour workspace Fabric, role assignments, Git integration
- `azuredevops` pour Azure DevOps project, repo, variable group, pipeline definition

## Recommandation pratique

Utiliser Terraform comme outil principal.

- Garder un module séparé par responsabilité.
- Éviter de créer la Git integration Fabric au premier run.
- Créer d'abord Azure + Entra + Fabric workspace.
- Ensuite configurer/valider la connexion Git Fabric/Azure DevOps.
- Enfin activer `enable_fabric_git_integration = true`.

## Niveau de complexité

| Sujet | Complexité | Commentaire |
|---|---:|---|
| ADLS2 landing zone | Faible | Ressources Azure standards avec provider AzureRM. |
| Entra groups | Moyenne | Dépend des droits Graph/Entra du principal Terraform. |
| Fabric Capacity | Faible à moyenne | Ressource AzureRM, mais le mapping avec Fabric prend parfois du délai. |
| Fabric Workspace | Moyenne | Via provider Fabric, nécessite les bons tenant settings. |
| Fabric roles | Moyenne | Fonctionne bien avec groupes Entra, mais dépend de la propagation des groupes. |
| Git Fabric -> Azure DevOps | Élevée | Preview + dépendance à une Fabric configured connection. |
| Azure DevOps project/repo | Moyenne | Requiert PAT ou bootstrap préalable. |

## Conclusion

Pour ton besoin Fabric + ADLS2 + Entra ID + Azure DevOps, Terraform est le meilleur choix car il donne une gouvernance unique. Bicep pourrait rester utile si le scope était uniquement Azure natif, mais ici le scope dépasse Azure ARM.
