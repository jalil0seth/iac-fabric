variable "subscription_id" {
  description = "Azure subscription id."
  type        = string
}

variable "tenant_id" {
  description = "Microsoft Entra tenant id."
  type        = string
}

variable "location" {
  description = "Azure region."
  type        = string
  default     = "francecentral"
}

variable "project_code" {
  description = "Short project code, for example mdm, fabric, data."
  type        = string
  default     = "fabric"
}

variable "environment" {
  description = "Environment name."
  type        = string
}

variable "owner" {
  description = "Business or technical owner tag."
  type        = string
  default     = "data-platform"
}

variable "create_entra_groups" {
  description = "Create Entra security groups. If false, provide existing_entra_group_object_ids."
  type        = bool
  default     = true
}

variable "existing_entra_group_object_ids" {
  description = "Existing group IDs when create_entra_groups=false or to override a specific group."
  type        = map(string)
  default     = {}
}

variable "terraform_principal_object_id" {
  description = "Object ID of the Service Principal or Managed Identity used by Azure DevOps/Terraform. Optional."
  type        = string
  default     = ""
}

variable "extra_fabric_admin_member_ids" {
  description = "Extra member object IDs to add into Fabric admins group."
  type        = list(string)
  default     = []
}

variable "extra_data_engineer_member_ids" {
  description = "Extra member object IDs to add into Data Engineers group."
  type        = list(string)
  default     = []
}

variable "storage_replication_type" {
  description = "ADLS replication type."
  type        = string
  default     = "LRS"
}

variable "enable_purge_protection" {
  description = "Enable Key Vault purge protection. Recommended true for prod."
  type        = bool
  default     = false
}

variable "public_network_access_enabled" {
  description = "Enable public network access. For production, consider private endpoints and set this false."
  type        = bool
  default     = true
}

variable "fabric_capacity_sku_name" {
  description = "Fabric capacity SKU. Example: F2, F4, F8, F16, F32, F64."
  type        = string
  default     = "F2"
}

variable "fabric_capacity_admin_members" {
  description = "Members allowed to administer Fabric capacity. Use email/UPN accepted by AzureRM Fabric capacity."
  type        = list(string)
}

variable "fabric_provider_preview_enabled" {
  description = "Enable preview resources in Fabric provider. Required for workspace Git integration."
  type        = bool
  default     = true
}

variable "enable_fabric_git_integration" {
  description = "Enable Fabric workspace Git integration to Azure DevOps."
  type        = bool
  default     = false
}

variable "fabric_git_connection_id" {
  description = "Fabric configured connection id for Azure DevOps source control. Required for Git integration with service principal."
  type        = string
  default     = ""
}

variable "fabric_git_directory_name" {
  description = "Directory in Azure DevOps repo used by Fabric Git integration."
  type        = string
  default     = "/fabric"
}

variable "fabric_git_branch_name" {
  description = "Branch used for Fabric Git integration."
  type        = string
  default     = "main"
}

variable "azure_devops_org_service_url" {
  description = "Azure DevOps organization URL, for example https://dev.azure.com/my-org. Required by azuredevops provider."
  type        = string
  default     = "https://dev.azure.com/your-org"
}

variable "azure_devops_organization_name" {
  description = "Azure DevOps organization short name used by Fabric Git integration."
  type        = string
  default     = "your-org"
}

variable "azure_devops_project_name" {
  description = "Azure DevOps project name."
  type        = string
  default     = "prj-fabric-platform"
}

variable "azure_devops_repository_name" {
  description = "Azure DevOps repository name."
  type        = string
  default     = "fabric-platform"
}

variable "create_azure_devops_project" {
  description = "Create Azure DevOps project/repo/variable group using Terraform. Requires AZDO_PERSONAL_ACCESS_TOKEN."
  type        = bool
  default     = false
}

variable "create_azure_devops_pipeline" {
  description = "Create Azure DevOps build definition. The repo must contain .azuredevops/azure-pipelines.yml."
  type        = bool
  default     = false
}

variable "common_tags" {
  description = "Extra tags."
  type        = map(string)
  default     = {}
}
