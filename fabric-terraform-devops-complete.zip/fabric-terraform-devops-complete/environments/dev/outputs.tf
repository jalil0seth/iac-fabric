output "entra_group_ids" {
  description = "Created or reused Entra group IDs."
  value       = module.entra.group_ids
}

output "resource_group_name" {
  value = module.landing_zone.resource_group_name
}

output "adls_storage_account_name" {
  value = module.landing_zone.storage_account_name
}

output "adls_dfs_endpoint" {
  value = module.landing_zone.storage_account_primary_dfs_endpoint
}

output "adls_filesystems" {
  value = module.landing_zone.filesystem_names
}

output "key_vault_uri" {
  value = module.landing_zone.key_vault_uri
}

output "fabric_capacity_arm_id" {
  value = module.fabric.capacity_arm_id
}

output "fabric_capacity_id" {
  value = module.fabric.capacity_fabric_id
}

output "fabric_workspace_id" {
  value = module.fabric.workspace_id
}

output "fabric_workspace_name" {
  value = module.fabric.workspace_display_name
}

output "fabric_workspace_git_enabled" {
  value = module.fabric.workspace_git_enabled
}
