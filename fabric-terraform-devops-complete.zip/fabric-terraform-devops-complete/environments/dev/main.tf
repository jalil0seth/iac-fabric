locals {
  normalized_project     = lower(replace(var.project_code, "_", "-"))
  normalized_environment = lower(var.environment)
  suffix                 = "${local.normalized_project}-${local.normalized_environment}"

  resource_group_name  = "rg-${local.suffix}-frc"
  storage_account_name = substr(replace("st${local.normalized_project}${local.normalized_environment}lz001", "-", ""), 0, 24)
  key_vault_name       = substr(replace("kv-${local.suffix}-001", "_", "-"), 0, 24)
  capacity_name        = "fc-${local.suffix}-001"
  workspace_name       = "ws-${local.suffix}-001"

  tags = merge(var.common_tags, {
    managed_by  = "terraform"
    platform    = "microsoft-fabric"
    environment = local.normalized_environment
    owner       = var.owner
  })

  entra_groups = {
    fabric_admins = {
      display_name = "grp-${local.suffix}-fabric-admins"
      description  = "Administrators for Fabric workspace and capacity."
    }
    data_engineers = {
      display_name = "grp-${local.suffix}-data-engineers"
      description  = "Contributors for ADLS and Fabric engineering."
    }
    data_readers = {
      display_name = "grp-${local.suffix}-data-readers"
      description  = "Readers for curated data and Fabric workspace."
    }
    devops_agents = {
      display_name = "grp-${local.suffix}-devops-agents"
      description  = "Service principals or managed identities used by CI/CD."
    }
  }

  group_members = {
    fabric_admins  = concat(var.extra_fabric_admin_member_ids, var.terraform_principal_object_id == "" ? [] : [var.terraform_principal_object_id])
    data_engineers = var.extra_data_engineer_member_ids
    data_readers   = []
    devops_agents  = var.terraform_principal_object_id == "" ? [] : [var.terraform_principal_object_id]
  }
}

module "entra" {
  source = "../../modules/entra"

  create_groups             = var.create_entra_groups
  groups                    = local.entra_groups
  existing_group_object_ids = var.existing_entra_group_object_ids
  group_members             = local.group_members
}

module "landing_zone" {
  source = "../../modules/azure_landing_zone"

  project_code                  = local.normalized_project
  environment                   = local.normalized_environment
  location                      = var.location
  tenant_id                     = var.tenant_id
  resource_group_name           = local.resource_group_name
  storage_account_name          = local.storage_account_name
  key_vault_name                = local.key_vault_name
  replication_type              = var.storage_replication_type
  enable_purge_protection       = var.enable_purge_protection
  public_network_access_enabled = var.public_network_access_enabled

  storage_blob_data_owner_principal_ids = compact([
    lookup(module.entra.group_ids, "fabric_admins", ""),
    lookup(module.entra.group_ids, "devops_agents", "")
  ])

  storage_blob_data_contributor_principal_ids = compact([
    lookup(module.entra.group_ids, "data_engineers", "")
  ])

  storage_blob_data_reader_principal_ids = compact([
    lookup(module.entra.group_ids, "data_readers", "")
  ])

  key_vault_admin_principal_ids = compact([
    lookup(module.entra.group_ids, "fabric_admins", ""),
    lookup(module.entra.group_ids, "devops_agents", "")
  ])

  tags = local.tags
}

module "fabric" {
  source = "../../modules/fabric"

  location                        = var.location
  resource_group_name             = module.landing_zone.resource_group_name
  capacity_name                   = local.capacity_name
  capacity_sku_name               = var.fabric_capacity_sku_name
  capacity_administration_members = var.fabric_capacity_admin_members
  workspace_display_name          = local.workspace_name
  workspace_description           = "Fabric workspace for ${local.normalized_project} ${local.normalized_environment}. Managed by Terraform."

  workspace_role_assignments = {
    fabric_admins = {
      principal_id   = module.entra.group_ids["fabric_admins"]
      principal_type = "Group"
      role           = "Admin"
    }
    data_engineers = {
      principal_id   = module.entra.group_ids["data_engineers"]
      principal_type = "Group"
      role           = "Contributor"
    }
    data_readers = {
      principal_id   = module.entra.group_ids["data_readers"]
      principal_type = "Group"
      role           = "Viewer"
    }
    devops_agents = {
      principal_id   = module.entra.group_ids["devops_agents"]
      principal_type = "Group"
      role           = "Admin"
    }
  }

  enable_git_integration = var.enable_fabric_git_integration
  git_connection_id      = var.fabric_git_connection_id

  azure_devops_git = {
    organization_name = var.azure_devops_organization_name
    project_name      = var.azure_devops_project_name
    repository_name   = var.azure_devops_repository_name
    branch_name       = var.fabric_git_branch_name
    directory_name    = var.fabric_git_directory_name
  }

  tags = local.tags

  depends_on = [module.landing_zone]
}

module "azure_devops_project" {
  count  = var.create_azure_devops_project ? 1 : 0
  source = "../../modules/azure_devops_project"

  project_name            = var.azure_devops_project_name
  project_description     = "Fabric platform IaC for ${local.normalized_project} ${local.normalized_environment}."
  repository_name         = var.azure_devops_repository_name
  create_build_definition = var.create_azure_devops_pipeline

  variables = {
    TF_VAR_subscription_id = {
      value     = var.subscription_id
      is_secret = false
    }
    TF_VAR_tenant_id = {
      value     = var.tenant_id
      is_secret = false
    }
    TF_ENVIRONMENT = {
      value     = local.normalized_environment
      is_secret = false
    }
  }
}
