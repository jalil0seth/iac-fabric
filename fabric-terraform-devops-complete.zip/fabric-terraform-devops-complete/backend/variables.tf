variable "subscription_id" {
  description = "Azure subscription id."
  type        = string
}

variable "tenant_id" {
  description = "Microsoft Entra tenant id."
  type        = string
}

variable "resource_group_name" {
  description = "Resource group for Terraform state."
  type        = string
}

variable "storage_account_name" {
  description = "Globally unique storage account name for Terraform state."
  type        = string
}

variable "container_name" {
  description = "Blob container for Terraform state."
  type        = string
  default     = "tfstate"
}

variable "location" {
  description = "Azure region."
  type        = string
  default     = "francecentral"
}

variable "replication_type" {
  description = "Storage replication for Terraform state."
  type        = string
  default     = "LRS"
}

variable "tags" {
  description = "Common tags."
  type        = map(string)
  default = {
    managed_by = "terraform"
    scope      = "tfstate"
  }
}
