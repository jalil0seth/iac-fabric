output "project_id" {
  value = azuredevops_project.this.id
}

output "project_name" {
  value = azuredevops_project.this.name
}

output "repository_id" {
  value = azuredevops_git_repository.this.id
}

output "repository_name" {
  value = azuredevops_git_repository.this.name
}

output "repository_web_url" {
  value = azuredevops_git_repository.this.web_url
}
