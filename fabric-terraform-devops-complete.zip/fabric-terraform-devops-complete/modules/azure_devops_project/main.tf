resource "azuredevops_project" "this" {
  name               = var.project_name
  description        = var.project_description
  visibility         = var.visibility
  version_control    = "Git"
  work_item_template = var.work_item_template

  features = {
    boards       = "disabled"
    repositories = "enabled"
    pipelines    = "enabled"
    artifacts    = "enabled"
    testplans    = "disabled"
  }
}

resource "azuredevops_git_repository" "this" {
  project_id = azuredevops_project.this.id
  name       = var.repository_name

  initialization {
    init_type = "Clean"
  }
}

resource "azuredevops_variable_group" "terraform" {
  count = var.create_variable_group ? 1 : 0

  project_id   = azuredevops_project.this.id
  name         = var.variable_group_name
  description  = "Terraform variables for Fabric platform."
  allow_access = true

  dynamic "variable" {
    for_each = var.variables

    content {
      name      = variable.key
      value     = variable.value.value
      is_secret = variable.value.is_secret
    }
  }
}

resource "azuredevops_build_definition" "terraform" {
  count = var.create_build_definition ? 1 : 0

  project_id = azuredevops_project.this.id
  name       = var.pipeline_name
  path       = "\\"

  repository {
    repo_type   = "TfsGit"
    repo_id     = azuredevops_git_repository.this.id
    branch_name = azuredevops_git_repository.this.default_branch
    yml_path    = var.pipeline_yml_path
  }
}
