variable "project_name" {
  type        = string
  description = "Azure DevOps project name."
}

variable "project_description" {
  type        = string
  description = "Azure DevOps project description."
  default     = "Fabric platform managed by Terraform."
}

variable "repository_name" {
  type        = string
  description = "Azure DevOps Git repository name."
}

variable "visibility" {
  type        = string
  description = "Project visibility."
  default     = "private"
}

variable "work_item_template" {
  type        = string
  description = "Work item template."
  default     = "Agile"
}

variable "create_variable_group" {
  type        = bool
  description = "Create an Azure DevOps variable group."
  default     = true
}

variable "variable_group_name" {
  type        = string
  description = "Variable group name."
  default     = "vg-terraform-fabric-platform"
}

variable "variables" {
  description = "Variables to create in Azure DevOps variable group. Do not store secrets here unless is_secret is true."
  type = map(object({
    value     = string
    is_secret = optional(bool, false)
  }))
  default = {}
}

variable "create_build_definition" {
  type        = bool
  description = "Create Azure DevOps pipeline build definition pointing to .azuredevops/azure-pipelines.yml."
  default     = false
}

variable "pipeline_name" {
  type        = string
  description = "Pipeline name."
  default     = "terraform-fabric-platform"
}

variable "pipeline_yml_path" {
  type        = string
  description = "Path to pipeline YAML in repo."
  default     = ".azuredevops/azure-pipelines.yml"
}
