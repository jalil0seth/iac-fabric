output "resource_group_name" {
  value = azurerm_resource_group.this.name
}

output "resource_group_id" {
  value = azurerm_resource_group.this.id
}

output "storage_account_id" {
  value = azurerm_storage_account.adls.id
}

output "storage_account_name" {
  value = azurerm_storage_account.adls.name
}

output "storage_account_primary_dfs_endpoint" {
  value = azurerm_storage_account.adls.primary_dfs_endpoint
}

output "filesystem_names" {
  value = keys(azurerm_storage_data_lake_gen2_filesystem.this)
}

output "key_vault_id" {
  value = azurerm_key_vault.this.id
}

output "key_vault_uri" {
  value = azurerm_key_vault.this.vault_uri
}
