variable "project_code" {
  type        = string
  description = "Short project code."
}

variable "environment" {
  type        = string
  description = "Environment name, for example dev, tst, prod."
}

variable "location" {
  type        = string
  description = "Azure region."
}

variable "resource_group_name" {
  type        = string
  description = "Resource group name."
}

variable "storage_account_name" {
  type        = string
  description = "ADLS Gen2 storage account name. Must be globally unique."
}

variable "key_vault_name" {
  type        = string
  description = "Key Vault name. Must be globally unique."
}

variable "tenant_id" {
  type        = string
  description = "Microsoft Entra tenant id."
}

variable "replication_type" {
  type        = string
  description = "Storage replication type."
  default     = "LRS"
}

variable "filesystems" {
  type        = list(string)
  description = "ADLS Gen2 filesystems to create."
  default     = ["landing", "bronze", "silver", "gold", "checkpoints", "config"]
}

variable "directories" {
  description = "Directories to create inside filesystems."
  type = list(object({
    filesystem = string
    path       = string
  }))
  default = []
}

variable "storage_blob_data_owner_principal_ids" {
  type        = list(string)
  description = "Principals to receive Storage Blob Data Owner on ADLS."
  default     = []
}

variable "storage_blob_data_contributor_principal_ids" {
  type        = list(string)
  description = "Principals to receive Storage Blob Data Contributor on ADLS."
  default     = []
}

variable "storage_blob_data_reader_principal_ids" {
  type        = list(string)
  description = "Principals to receive Storage Blob Data Reader on ADLS."
  default     = []
}

variable "key_vault_admin_principal_ids" {
  type        = list(string)
  description = "Principals to receive Key Vault Administrator."
  default     = []
}

variable "enable_purge_protection" {
  type        = bool
  description = "Enable purge protection on Key Vault. Recommended true for prod."
  default     = false
}

variable "public_network_access_enabled" {
  type        = bool
  description = "Enable public network access for Storage and Key Vault."
  default     = true
}

variable "tags" {
  type        = map(string)
  description = "Common tags."
  default     = {}
}
