locals {
  default_directories = flatten([
    for fs in ["landing", "bronze", "silver", "gold"] : [
      for entity in ["organisation", "person", "clients", "chantiers", "prestation"] : {
        filesystem = fs
        path       = entity
      }
    ]
  ])

  all_directories = concat(local.default_directories, var.directories)

  directories_map = {
    for dir in local.all_directories : "${dir.filesystem}/${dir.path}" => dir
  }

  storage_role_assignments = concat(
    [for principal_id in var.storage_blob_data_owner_principal_ids : {
      principal_id         = principal_id
      role_definition_name = "Storage Blob Data Owner"
    }],
    [for principal_id in var.storage_blob_data_contributor_principal_ids : {
      principal_id         = principal_id
      role_definition_name = "Storage Blob Data Contributor"
    }],
    [for principal_id in var.storage_blob_data_reader_principal_ids : {
      principal_id         = principal_id
      role_definition_name = "Storage Blob Data Reader"
    }]
  )
}

resource "azurerm_resource_group" "this" {
  name     = var.resource_group_name
  location = var.location
  tags     = var.tags
}

resource "azurerm_storage_account" "adls" {
  name                            = var.storage_account_name
  resource_group_name             = azurerm_resource_group.this.name
  location                        = azurerm_resource_group.this.location
  account_tier                    = "Standard"
  account_replication_type        = var.replication_type
  account_kind                    = "StorageV2"
  is_hns_enabled                  = true
  min_tls_version                 = "TLS1_2"
  allow_nested_items_to_be_public = false
  public_network_access_enabled   = var.public_network_access_enabled

  blob_properties {
    versioning_enabled = true

    delete_retention_policy {
      days = 30
    }

    container_delete_retention_policy {
      days = 30
    }
  }

  tags = var.tags
}

resource "azurerm_storage_data_lake_gen2_filesystem" "this" {
  for_each = toset(var.filesystems)

  name               = each.key
  storage_account_id = azurerm_storage_account.adls.id
}

resource "azurerm_storage_data_lake_gen2_path" "directories" {
  for_each = local.directories_map

  path               = each.value.path
  filesystem_name    = azurerm_storage_data_lake_gen2_filesystem.this[each.value.filesystem].name
  storage_account_id = azurerm_storage_account.adls.id
  resource           = "directory"
}

resource "azurerm_key_vault" "this" {
  name                        = var.key_vault_name
  location                    = azurerm_resource_group.this.location
  resource_group_name         = azurerm_resource_group.this.name
  tenant_id                   = var.tenant_id
  sku_name                    = "standard"
  enable_rbac_authorization   = true
  soft_delete_retention_days  = 7
  purge_protection_enabled    = var.enable_purge_protection
  public_network_access_enabled = var.public_network_access_enabled

  tags = var.tags
}

resource "azurerm_role_assignment" "storage" {
  for_each = {
    for assignment in local.storage_role_assignments : "${assignment.role_definition_name}-${assignment.principal_id}" => assignment
  }

  scope                            = azurerm_storage_account.adls.id
  role_definition_name             = each.value.role_definition_name
  principal_id                     = each.value.principal_id
  skip_service_principal_aad_check = true
}

resource "azurerm_role_assignment" "key_vault_admin" {
  for_each = toset(var.key_vault_admin_principal_ids)

  scope                            = azurerm_key_vault.this.id
  role_definition_name             = "Key Vault Administrator"
  principal_id                     = each.key
  skip_service_principal_aad_check = true
}
