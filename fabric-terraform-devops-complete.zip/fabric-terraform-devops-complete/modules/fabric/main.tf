resource "azurerm_fabric_capacity" "this" {
  name                = var.capacity_name
  location            = var.location
  resource_group_name = var.resource_group_name

  administration_members = var.capacity_administration_members

  sku {
    name = var.capacity_sku_name
    tier = "Fabric"
  }

  tags = var.tags
}

resource "time_sleep" "wait_for_capacity_registration" {
  depends_on      = [azurerm_fabric_capacity.this]
  create_duration = "90s"
}

data "fabric_capacity" "this" {
  display_name = azurerm_fabric_capacity.this.name

  depends_on = [time_sleep.wait_for_capacity_registration]
}

resource "fabric_workspace" "this" {
  display_name = var.workspace_display_name
  description  = var.workspace_description
  capacity_id  = data.fabric_capacity.this.id
}

resource "fabric_workspace_role_assignment" "this" {
  for_each = var.workspace_role_assignments

  workspace_id   = fabric_workspace.this.id
  principal_id   = each.value.principal_id
  principal_type = each.value.principal_type
  role           = each.value.role
}

resource "fabric_workspace_git" "azure_devops" {
  count = var.enable_git_integration && var.git_connection_id != "" ? 1 : 0

  workspace_id            = fabric_workspace.this.id
  initialization_strategy = var.git_initialization_strategy

  git_provider_details = {
    git_provider_type = "AzureDevOps"
    organization_name = var.azure_devops_git.organization_name
    project_name      = var.azure_devops_git.project_name
    repository_name   = var.azure_devops_git.repository_name
    branch_name       = var.azure_devops_git.branch_name
    directory_name    = var.azure_devops_git.directory_name
  }

  git_credentials = {
    source        = "ConfiguredConnection"
    connection_id = var.git_connection_id
  }
}
