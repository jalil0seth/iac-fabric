output "capacity_arm_id" {
  value = azurerm_fabric_capacity.this.id
}

output "capacity_fabric_id" {
  value = data.fabric_capacity.this.id
}

output "workspace_id" {
  value = fabric_workspace.this.id
}

output "workspace_display_name" {
  value = fabric_workspace.this.display_name
}

output "workspace_git_enabled" {
  value = length(fabric_workspace_git.azure_devops) > 0
}
