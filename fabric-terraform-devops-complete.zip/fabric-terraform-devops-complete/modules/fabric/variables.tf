variable "location" {
  type        = string
  description = "Azure region for Fabric capacity."
}

variable "resource_group_name" {
  type        = string
  description = "Resource group where Fabric capacity is created."
}

variable "capacity_name" {
  type        = string
  description = "Fabric capacity name."
}

variable "capacity_sku_name" {
  type        = string
  description = "Fabric capacity SKU, for example F2, F4, F8, F16."
  default     = "F2"
}

variable "capacity_administration_members" {
  type        = list(string)
  description = "Emails or user identifiers for Fabric capacity administrators."
}

variable "workspace_display_name" {
  type        = string
  description = "Fabric workspace display name."
}

variable "workspace_description" {
  type        = string
  description = "Fabric workspace description."
  default     = "Managed by Terraform."
}

variable "workspace_role_assignments" {
  description = "Fabric workspace role assignments."
  type = map(object({
    principal_id   = string
    principal_type = string
    role           = string
  }))
  default = {}
}

variable "enable_git_integration" {
  type        = bool
  description = "Enable Fabric workspace Git integration. Requires fabric provider preview mode and a configured connection id."
  default     = false
}

variable "git_connection_id" {
  type        = string
  description = "Fabric configured connection id for Azure DevOps source control. Required when enable_git_integration is true."
  default     = ""
}

variable "git_initialization_strategy" {
  type        = string
  description = "Fabric Git initialization strategy. Common values: PreferWorkspace or PreferRemote."
  default     = "PreferWorkspace"
}

variable "azure_devops_git" {
  description = "Azure DevOps Git details for Fabric integration."
  type = object({
    organization_name = string
    project_name      = string
    repository_name   = string
    branch_name       = string
    directory_name    = string
  })
  default = {
    organization_name = ""
    project_name      = ""
    repository_name   = ""
    branch_name       = "main"
    directory_name    = "/fabric"
  }
}

variable "tags" {
  type        = map(string)
  description = "Common tags."
  default     = {}
}
