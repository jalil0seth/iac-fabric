variable "create_groups" {
  description = "Create Entra ID security groups. If false, use existing_group_object_ids."
  type        = bool
  default     = true
}

variable "groups" {
  description = "Map of Entra groups to create."
  type = map(object({
    display_name = string
    description  = optional(string, null)
  }))
}

variable "existing_group_object_ids" {
  description = "Existing Entra group object ids keyed by the same logical keys as groups."
  type        = map(string)
  default     = {}
}

variable "group_members" {
  description = "Members to add to groups. Key is group logical name, value is list of member object ids."
  type        = map(list(string))
  default     = {}
}
