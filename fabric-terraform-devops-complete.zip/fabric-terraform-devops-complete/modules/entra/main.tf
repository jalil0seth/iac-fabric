locals {
  groups_to_create = var.create_groups ? var.groups : {}

  group_ids = merge(
    var.existing_group_object_ids,
    { for key, group in azuread_group.this : key => group.object_id }
  )

  member_pairs = flatten([
    for group_key, member_ids in var.group_members : [
      for member_id in member_ids : {
        group_key = group_key
        member_id = member_id
      }
      if member_id != null && member_id != "" && contains(keys(local.group_ids), group_key)
    ]
  ])
}

resource "azuread_group" "this" {
  for_each = local.groups_to_create

  display_name     = each.value.display_name
  description      = each.value.description
  security_enabled = true
  mail_enabled     = false
  mail_nickname    = substr(replace(lower(each.value.display_name), " ", "-"), 0, 64)
}

resource "azuread_group_member" "this" {
  for_each = {
    for pair in local.member_pairs : "${pair.group_key}-${pair.member_id}" => pair
  }

  group_object_id  = local.group_ids[each.value.group_key]
  member_object_id = each.value.member_id
}
