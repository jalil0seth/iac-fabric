output "group_ids" {
  description = "Map of logical group keys to Entra object IDs."
  value       = local.group_ids
}

output "created_group_names" {
  description = "Display names for groups created by this module."
  value       = { for key, group in azuread_group.this : key => group.display_name }
}
