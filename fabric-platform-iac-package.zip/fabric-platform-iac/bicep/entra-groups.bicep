targetScope = 'tenant'
extension microsoftGraphV1

@description('Project prefix')
param prefix string = 'mdm'

@description('Environment')
param environment string = 'dev'

var groups = [
  {
    name: 'sg-${prefix}-${environment}-fabric-platform-admins'
    description: 'Fabric platform administrators'
  }
  {
    name: 'sg-${prefix}-${environment}-fabric-workspace-admins'
    description: 'Fabric workspace administrators'
  }
  {
    name: 'sg-${prefix}-${environment}-fabric-workspace-contributors'
    description: 'Fabric workspace contributors'
  }
  {
    name: 'sg-${prefix}-${environment}-fabric-workspace-viewers'
    description: 'Fabric workspace viewers'
  }
  {
    name: 'sg-${prefix}-${environment}-adls-data-engineers'
    description: 'ADLS data engineers'
  }
  {
    name: 'sg-${prefix}-${environment}-azdo-iac-deployers'
    description: 'Azure DevOps IaC deployers'
  }
]

resource entraGroups 'Microsoft.Graph/groups@v1.0' = [for g in groups: {
  uniqueName: g.name
  displayName: g.name
  description: g.description
  mailEnabled: false
  mailNickname: replace(g.name, '-', '')
  securityEnabled: true
  groupTypes: []
}]

output groupObjectIds array = [for (g, i) in groups: {
  name: g.name
  objectId: entraGroups[i].id
}]
