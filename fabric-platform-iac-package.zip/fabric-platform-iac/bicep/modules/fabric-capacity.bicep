param name string
param location string
param skuName string = 'F2'
param administrationMembers array = []
param tags object = {}

resource capacity 'Microsoft.Fabric/capacities@2025-01-15-preview' = {
  name: name
  location: location
  tags: tags
  sku: {
    name: skuName
    tier: 'Fabric'
  }
  properties: {
    administration: {
      members: administrationMembers
    }
  }
}

output fabricCapacityAzureResourceId string = capacity.id
output fabricCapacityName string = capacity.name
