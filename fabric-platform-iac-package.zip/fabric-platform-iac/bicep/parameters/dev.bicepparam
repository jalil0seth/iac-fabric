using '../main.bicep'

param prefix = 'mdm'
param environment = 'dev'
param location = 'francecentral'
param fabricCapacitySku = 'F2'

// Replace by real Entra object IDs.
param fabricCapacityAdminMembers = [
  '<sg-fabric-platform-admins-object-id>'
]

param adlsContributorPrincipalIds = [
  '<sg-adls-data-engineers-object-id>'
  '<sg-fabric-workspace-contributors-object-id>'
]

param readerPrincipalIds = [
  '<sg-fabric-workspace-viewers-object-id>'
]

param storagePublicNetworkAccess = true

param tags = {
  workload: 'fabric-platform'
  env: 'dev'
  managedBy: 'bicep'
}
