# Projet Bicep - Azure Landing Zone + Fabric Capacity + Scripts Fabric REST

## Objectif

Ce projet déploie les ressources Azure natives en Bicep :

- Resource Group.
- ADLS Gen2 / Storage Account.
- Conteneurs : landing, bronze, silver, gold, logs, archive.
- Key Vault.
- Managed Identity optionnelle pour automatisation.
- Fabric Capacity F-SKU via ARM/Bicep.
- Azure RBAC sur ADLS.

Le workspace Fabric, ses rôles et la connexion Git sont automatisés via scripts PowerShell REST API, car ces opérations sont mieux couvertes par l'API Fabric que par ARM/Bicep pur.

## Déploiement local

```bash
az login
az account set --subscription <subscription-id>

az deployment sub create \
  --location francecentral \
  --template-file ./main.bicep \
  --parameters ./parameters/dev.bicepparam
```

Ensuite, lancer le script Fabric :

```powershell
./scripts/create-or-update-fabric-workspace.ps1 \
  -WorkspaceName "ws-mdm-dev-fabric" \
  -CapacityId "<fabric-capacity-guid>" \
  -AdminGroupObjectId "<group-object-id>" \
  -ContributorGroupObjectId "<group-object-id>" \
  -ViewerGroupObjectId "<group-object-id>"
```

## Déploiement Azure DevOps

Utiliser `pipelines/azure-pipelines-bicep.yml`.

## Important

- Les groupes Entra peuvent être créés via `scripts/bootstrap-entra-groups.sh` ou via `entra-groups.bicep` si ton pipeline a les permissions Microsoft Graph nécessaires.
- Les Fabric REST APIs requièrent un token pour `https://api.fabric.microsoft.com` et des permissions Fabric suffisantes.
