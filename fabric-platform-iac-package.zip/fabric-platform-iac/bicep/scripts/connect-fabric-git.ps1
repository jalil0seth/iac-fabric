param(
  [Parameter(Mandatory=$true)][string]$WorkspaceName,
  [Parameter(Mandatory=$true)][string]$OrganizationName,
  [Parameter(Mandatory=$true)][string]$ProjectName,
  [Parameter(Mandatory=$true)][string]$RepositoryName,
  [Parameter(Mandatory=$true)][string]$BranchName,
  [Parameter(Mandatory=$false)][string]$DirectoryName = '/',
  [Parameter(Mandatory=$false)][string]$ConnectionId
)

$ErrorActionPreference = 'Stop'

function Get-FabricHeaders {
  $token = az account get-access-token --resource https://api.fabric.microsoft.com --query accessToken -o tsv
  return @{ Authorization = "Bearer $token"; 'Content-Type' = 'application/json' }
}

$headers = Get-FabricHeaders
$workspaces = Invoke-RestMethod -Method GET -Uri 'https://api.fabric.microsoft.com/v1/workspaces' -Headers $headers
$workspace = $workspaces.value | Where-Object { $_.displayName -eq $WorkspaceName } | Select-Object -First 1
if (-not $workspace) { throw "Workspace not found: $WorkspaceName" }

$body = @{
  gitProviderDetails = @{
    organizationName = $OrganizationName
    projectName = $ProjectName
    gitProviderType = 'AzureDevOps'
    repositoryName = $RepositoryName
    branchName = $BranchName
    directoryName = $DirectoryName
  }
}

if ($ConnectionId) {
  $body.myGitCredentials = @{
    source = 'ConfiguredConnection'
    connectionId = $ConnectionId
  }
}

try {
  Invoke-RestMethod -Method POST -Uri "https://api.fabric.microsoft.com/v1/workspaces/$($workspace.id)/git/connect" -Headers $headers -Body ($body | ConvertTo-Json -Depth 20) | Out-Null
  Write-Host "Git connected for workspace $WorkspaceName."
} catch {
  if ($_.Exception.Message -like '*WorkspaceAlreadyConnectedToGit*') {
    Write-Host "Workspace already connected to Git."
  } else {
    throw
  }
}
