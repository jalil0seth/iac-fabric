param(
  [Parameter(Mandatory=$true)][string]$WorkspaceId,
  [Parameter(Mandatory=$true)][string]$PrincipalId,
  [Parameter(Mandatory=$true)][ValidateSet('Admin','Member','Contributor','Viewer')][string]$Role,
  [Parameter(Mandatory=$false)][ValidateSet('User','Group','ServicePrincipal')][string]$PrincipalType = 'Group'
)

$ErrorActionPreference = 'Stop'
$token = az account get-access-token --resource https://api.fabric.microsoft.com --query accessToken -o tsv
$headers = @{ Authorization = "Bearer $token"; 'Content-Type' = 'application/json' }

$body = @{
  principal = @{
    id = $PrincipalId
    type = $PrincipalType
  }
  role = $Role
} | ConvertTo-Json -Depth 10

Invoke-RestMethod -Method POST -Uri "https://api.fabric.microsoft.com/v1/workspaces/$WorkspaceId/roleAssignments" -Headers $headers -Body $body | Out-Null
Write-Host "Assigned $Role to $PrincipalType $PrincipalId on workspace $WorkspaceId."
