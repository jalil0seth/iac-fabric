#!/usr/bin/env bash
set -euo pipefail

PREFIX="${1:-mdm}"
ENVIRONMENT="${2:-dev}"

GROUPS=(
  "sg-${PREFIX}-${ENVIRONMENT}-fabric-platform-admins"
  "sg-${PREFIX}-${ENVIRONMENT}-fabric-workspace-admins"
  "sg-${PREFIX}-${ENVIRONMENT}-fabric-workspace-contributors"
  "sg-${PREFIX}-${ENVIRONMENT}-fabric-workspace-viewers"
  "sg-${PREFIX}-${ENVIRONMENT}-adls-data-engineers"
  "sg-${PREFIX}-${ENVIRONMENT}-azdo-iac-deployers"
)

for group in "${GROUPS[@]}"; do
  existing=$(az ad group list --filter "displayName eq '${group}'" --query "[0].id" -o tsv || true)
  if [[ -z "${existing}" ]]; then
    echo "Creating ${group}"
    az ad group create --display-name "${group}" --mail-nickname "${group//-/}" --security-enabled true --query "{name:displayName, objectId:id}" -o table
  else
    echo "Exists ${group}: ${existing}"
  fi
done
