param(
  [Parameter(Mandatory=$true)][string]$WorkspaceName,
  [Parameter(Mandatory=$false)][string]$CapacityId,
  [Parameter(Mandatory=$false)][string]$Description = 'Fabric workspace managed by Azure DevOps IaC',
  [Parameter(Mandatory=$false)][string]$AdminGroupObjectId,
  [Parameter(Mandatory=$false)][string]$ContributorGroupObjectId,
  [Parameter(Mandatory=$false)][string]$ViewerGroupObjectId
)

$ErrorActionPreference = 'Stop'

function Get-FabricHeaders {
  $token = az account get-access-token --resource https://api.fabric.microsoft.com --query accessToken -o tsv
  if (-not $token) { throw 'Unable to acquire Fabric access token. Check Azure DevOps service connection and Fabric tenant settings.' }
  return @{ Authorization = "Bearer $token"; 'Content-Type' = 'application/json' }
}

function Invoke-FabricRest {
  param(
    [Parameter(Mandatory=$true)][string]$Method,
    [Parameter(Mandatory=$true)][string]$Uri,
    [Parameter(Mandatory=$false)]$Body
  )
  $headers = Get-FabricHeaders
  if ($Body) {
    $json = $Body | ConvertTo-Json -Depth 20
    return Invoke-RestMethod -Method $Method -Uri $Uri -Headers $headers -Body $json
  }
  return Invoke-RestMethod -Method $Method -Uri $Uri -Headers $headers
}

function Add-FabricWorkspaceRoleIfNeeded {
  param(
    [Parameter(Mandatory=$true)][string]$WorkspaceId,
    [Parameter(Mandatory=$true)][string]$PrincipalId,
    [Parameter(Mandatory=$true)][ValidateSet('Admin','Member','Contributor','Viewer')][string]$Role
  )

  $assignments = Invoke-FabricRest -Method GET -Uri "https://api.fabric.microsoft.com/v1/workspaces/$WorkspaceId/roleAssignments"
  $exists = $assignments.value | Where-Object { $_.principal.id -eq $PrincipalId }
  if ($exists) {
    Write-Host "Role assignment already exists for $PrincipalId as $($exists.role)."
    return
  }

  $body = @{
    principal = @{
      id = $PrincipalId
      type = 'Group'
    }
    role = $Role
  }
  Invoke-FabricRest -Method POST -Uri "https://api.fabric.microsoft.com/v1/workspaces/$WorkspaceId/roleAssignments" -Body $body | Out-Null
  Write-Host "Assigned $Role to group $PrincipalId on workspace $WorkspaceId."
}

$workspaces = Invoke-FabricRest -Method GET -Uri 'https://api.fabric.microsoft.com/v1/workspaces'
$workspace = $workspaces.value | Where-Object { $_.displayName -eq $WorkspaceName } | Select-Object -First 1

if (-not $workspace) {
  $createBody = @{
    displayName = $WorkspaceName
    description = $Description
  }
  if ($CapacityId) { $createBody.capacityId = $CapacityId }
  $workspace = Invoke-FabricRest -Method POST -Uri 'https://api.fabric.microsoft.com/v1/workspaces' -Body $createBody
  Write-Host "Created Fabric workspace $WorkspaceName with id $($workspace.id)."
} else {
  Write-Host "Fabric workspace already exists: $WorkspaceName with id $($workspace.id)."
}

if ($CapacityId -and ($workspace.capacityId -ne $CapacityId)) {
  Invoke-FabricRest -Method POST -Uri "https://api.fabric.microsoft.com/v1/workspaces/$($workspace.id)/assignToCapacity" -Body @{ capacityId = $CapacityId } | Out-Null
  Write-Host "Capacity assignment requested for workspace $($workspace.id)."
}

if ($AdminGroupObjectId) { Add-FabricWorkspaceRoleIfNeeded -WorkspaceId $workspace.id -PrincipalId $AdminGroupObjectId -Role 'Admin' }
if ($ContributorGroupObjectId) { Add-FabricWorkspaceRoleIfNeeded -WorkspaceId $workspace.id -PrincipalId $ContributorGroupObjectId -Role 'Contributor' }
if ($ViewerGroupObjectId) { Add-FabricWorkspaceRoleIfNeeded -WorkspaceId $workspace.id -PrincipalId $ViewerGroupObjectId -Role 'Viewer' }

Write-Host "WorkspaceId=$($workspace.id)"
