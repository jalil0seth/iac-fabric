targetScope = 'subscription'

@description('Short project prefix. Example: mdm, data, fabric.')
param prefix string = 'mdm'

@allowed([
  'dev'
  'test'
  'prod'
])
@description('Environment code.')
param environment string = 'dev'

@description('Azure region. For France use francecentral.')
param location string = 'francecentral'

@description('Tags applied to Azure resources.')
param tags object = {
  workload: 'fabric-platform'
  owner: 'data-platform'
  managedBy: 'bicep'
}

@description('Object IDs of Entra groups/users/SPs that will be Storage Blob Data Contributor on ADLS.')
param adlsContributorPrincipalIds array = []

@description('Object IDs of Entra groups/users/SPs that will be Reader on the resource group.')
param readerPrincipalIds array = []

@description('Object IDs or UPNs accepted by Microsoft.Fabric capacity administration.members. Prefer Entra object IDs for workload identities.')
param fabricCapacityAdminMembers array = []

@description('Fabric Capacity SKU. For dev use F2/F4 if enabled in your subscription.')
param fabricCapacitySku string = 'F2'

@description('Enable public network access for storage. Use false with private endpoints in stricter environments.')
param storagePublicNetworkAccess bool = true

var cleanPrefix = toLower(replace(prefix, '-', ''))
var suffix = '${cleanPrefix}${environment}'
var rgName = 'rg-${prefix}-${environment}-fabric'
var storageName = take('${cleanPrefix}${environment}adls${uniqueString(subscription().id, prefix, environment)}', 24)
var kvName = take('kv-${prefix}-${environment}-${uniqueString(subscription().id, prefix, environment)}', 24)
var capacityName = take('${cleanPrefix}${environment}fabric${uniqueString(subscription().id, prefix, environment)}', 63)
var identityName = 'id-${prefix}-${environment}-fabric-automation'

resource rg 'Microsoft.Resources/resourceGroups@2024-03-01' = {
  name: rgName
  location: location
  tags: tags
}

module identity './modules/managed-identity.bicep' = {
  name: 'mi-${suffix}'
  scope: rg
  params: {
    name: identityName
    location: location
    tags: tags
  }
}

module storage './modules/storage-adls2.bicep' = {
  name: 'storage-${suffix}'
  scope: rg
  params: {
    name: storageName
    location: location
    tags: tags
    publicNetworkAccess: storagePublicNetworkAccess ? 'Enabled' : 'Disabled'
    containers: [
      'landing'
      'bronze'
      'silver'
      'gold'
      'logs'
      'archive'
    ]
  }
}

module keyVault './modules/keyvault.bicep' = {
  name: 'kv-${suffix}'
  scope: rg
  params: {
    name: kvName
    location: location
    tags: tags
  }
}

module fabricCapacity './modules/fabric-capacity.bicep' = {
  name: 'fabric-capacity-${suffix}'
  scope: rg
  params: {
    name: capacityName
    location: location
    skuName: fabricCapacitySku
    administrationMembers: fabricCapacityAdminMembers
    tags: tags
  }
}

module adlsRbac './modules/rbac-storage.bicep' = {
  name: 'rbac-adls-${suffix}'
  scope: rg
  params: {
    storageAccountName: storage.outputs.storageAccountName
    principalIds: adlsContributorPrincipalIds
  }
}

module rgReader './modules/rbac-resource-group-reader.bicep' = {
  name: 'rbac-rg-reader-${suffix}'
  scope: rg
  params: {
    principalIds: readerPrincipalIds
  }
}

output resourceGroupName string = rg.name
output storageAccountName string = storage.outputs.storageAccountName
output storageBlobEndpoint string = storage.outputs.blobEndpoint
output keyVaultName string = keyVault.outputs.keyVaultName
output managedIdentityClientId string = identity.outputs.clientId
output managedIdentityPrincipalId string = identity.outputs.principalId
output fabricCapacityAzureResourceId string = fabricCapacity.outputs.fabricCapacityAzureResourceId
output fabricCapacityName string = fabricCapacity.outputs.fabricCapacityName
