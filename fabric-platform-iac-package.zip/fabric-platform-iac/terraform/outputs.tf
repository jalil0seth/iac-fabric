output "resource_group_name" {
  value = azurerm_resource_group.this.name
}

output "storage_account_name" {
  value = module.adls2.storage_account_name
}

output "adls_containers" {
  value = module.adls2.container_names
}

output "key_vault_name" {
  value = azurerm_key_vault.this.name
}

output "fabric_capacity_azure_id" {
  value = azurerm_fabric_capacity.this.id
}

output "fabric_capacity_id" {
  value = data.fabric_capacity.this.id
}

output "fabric_workspace_id" {
  value = fabric_workspace.this.id
}

output "entra_group_object_ids" {
  value = local.group_object_ids
}
