locals {
  clean_prefix   = lower(replace(var.prefix, "-", ""))
  name_suffix    = "${var.prefix}-${var.environment}"
  compact_suffix = "${local.clean_prefix}${var.environment}"

  resource_group_name = "rg-${local.name_suffix}-fabric"
  workspace_name      = coalesce(var.fabric_workspace_name, "ws-${local.name_suffix}-fabric")

  standard_groups = {
    platform_admins        = "sg-${local.name_suffix}-fabric-platform-admins"
    workspace_admins       = "sg-${local.name_suffix}-fabric-workspace-admins"
    workspace_contributors = "sg-${local.name_suffix}-fabric-workspace-contributors"
    workspace_viewers      = "sg-${local.name_suffix}-fabric-workspace-viewers"
    adls_data_engineers    = "sg-${local.name_suffix}-adls-data-engineers"
    azdo_iac_deployers     = "sg-${local.name_suffix}-azdo-iac-deployers"
  }
}

resource "random_string" "suffix" {
  length  = 6
  upper   = false
  special = false
}

resource "azurerm_resource_group" "this" {
  name     = local.resource_group_name
  location = var.location
  tags     = var.tags
}

resource "azuread_group" "standard" {
  for_each = var.create_entra_groups ? local.standard_groups : {}

  display_name     = each.value
  security_enabled = true
  mail_enabled     = false
  mail_nickname    = replace(each.value, "-", "")
}

locals {
  group_object_ids = var.create_entra_groups ? {
    for k, v in azuread_group.standard : k => v.object_id
  } : {
    platform_admins        = var.existing_group_object_ids.platform_admins
    workspace_admins       = var.existing_group_object_ids.workspace_admins
    workspace_contributors = var.existing_group_object_ids.workspace_contributors
    workspace_viewers      = var.existing_group_object_ids.workspace_viewers
    adls_data_engineers    = var.existing_group_object_ids.adls_data_engineers
    azdo_iac_deployers     = var.existing_group_object_ids.azdo_iac_deployers
  }
}

module "identity" {
  source              = "./modules/identity"
  name                = "id-${local.name_suffix}-fabric-automation"
  resource_group_name = azurerm_resource_group.this.name
  location            = azurerm_resource_group.this.location
  tags                = var.tags
}

module "adls2" {
  source              = "./modules/adls2"
  name                = substr("${local.compact_suffix}adls${random_string.suffix.result}", 0, 24)
  resource_group_name = azurerm_resource_group.this.name
  location            = azurerm_resource_group.this.location
  tags                = var.tags
}

resource "azurerm_key_vault" "this" {
  name                      = substr("kv-${local.name_suffix}-${random_string.suffix.result}", 0, 24)
  location                  = azurerm_resource_group.this.location
  resource_group_name       = azurerm_resource_group.this.name
  tenant_id                 = var.tenant_id
  sku_name                  = "standard"
  enable_rbac_authorization = true
  soft_delete_retention_days = 90
  tags                      = var.tags
}

module "rbac" {
  source = "./modules/rbac"

  storage_account_id = module.adls2.storage_account_id
  adls_contributor_principal_ids = compact([
    local.group_object_ids.adls_data_engineers,
    local.group_object_ids.workspace_contributors,
    local.group_object_ids.workspace_admins
  ])
}

resource "azurerm_fabric_capacity" "this" {
  name                = substr("${local.compact_suffix}fabric${random_string.suffix.result}", 0, 63)
  resource_group_name = azurerm_resource_group.this.name
  location            = azurerm_resource_group.this.location
  administration_members = compact([
    local.group_object_ids.platform_admins,
    local.group_object_ids.workspace_admins
  ])

  sku {
    name = var.fabric_capacity_sku
    tier = "Fabric"
  }

  tags = var.tags
}

# Fabric provider needs the Fabric Capacity GUID, not the Azure resource ID.
# If the azurerm resource doesn't expose the capacity GUID in your provider version,
# use data.fabric_capacity by display_name after capacity creation.
data "fabric_capacity" "this" {
  display_name = azurerm_fabric_capacity.this.name

  lifecycle {
    postcondition {
      condition     = self.state == "Active"
      error_message = "Fabric Capacity is not Active. Check Azure/Fabric capacity status."
    }
  }
}

resource "fabric_workspace" "this" {
  display_name = local.workspace_name
  description  = "Fabric workspace managed by Terraform for ${var.environment}."
  capacity_id  = data.fabric_capacity.this.id

  identity = {
    type = "SystemAssigned"
  }
}

resource "fabric_workspace_role_assignment" "admins" {
  workspace_id = fabric_workspace.this.id
  principal = {
    id   = local.group_object_ids.workspace_admins
    type = "Group"
  }
  role = "Admin"
}

resource "fabric_workspace_role_assignment" "contributors" {
  workspace_id = fabric_workspace.this.id
  principal = {
    id   = local.group_object_ids.workspace_contributors
    type = "Group"
  }
  role = "Contributor"
}

resource "fabric_workspace_role_assignment" "viewers" {
  workspace_id = fabric_workspace.this.id
  principal = {
    id   = local.group_object_ids.workspace_viewers
    type = "Group"
  }
  role = "Viewer"
}

resource "fabric_workspace_git" "azdo" {
  count                   = var.enable_fabric_git ? 1 : 0
  workspace_id            = fabric_workspace.this.id
  initialization_strategy = "PreferWorkspace"

  git_provider_details = {
    git_provider_type = "AzureDevOps"
    organization_name = var.azdo_git.organization_name
    project_name      = var.azdo_git.project_name
    repository_name   = var.azdo_git.repository_name
    branch_name       = var.azdo_git.branch_name
    directory_name    = var.azdo_git.directory_name
  }

  git_credentials = var.azdo_git.credentials_source == "ConfiguredConnection" ? {
    source        = "ConfiguredConnection"
    connection_id = var.azdo_git.connection_id
  } : {
    source = "Automatic"
  }

  depends_on = [
    fabric_workspace_role_assignment.admins
  ]
}
