provider "azurerm" {
  features {}
  subscription_id = var.subscription_id
  tenant_id       = var.tenant_id
  use_oidc        = var.use_oidc
  client_id       = var.client_id
}

provider "azuread" {
  tenant_id = var.tenant_id
  use_oidc  = var.use_oidc
  client_id = var.client_id
}

provider "fabric" {
  tenant_id        = var.tenant_id
  use_oidc         = var.use_oidc
  use_azuread_auth = true
  client_id        = var.client_id
  preview          = true
}
