variable "storage_account_id" { type = string }
variable "adls_contributor_principal_ids" { type = list(string) }

resource "azurerm_role_assignment" "adls_blob_contributor" {
  for_each = toset(var.adls_contributor_principal_ids)

  scope                = var.storage_account_id
  role_definition_name = "Storage Blob Data Contributor"
  principal_id         = each.value
}
