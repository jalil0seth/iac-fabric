variable "subscription_id" {
  description = "Azure subscription id."
  type        = string
}

variable "tenant_id" {
  description = "Microsoft Entra tenant id."
  type        = string
}

variable "client_id" {
  description = "Client id used by Azure DevOps workload identity federation. Leave empty for local az login."
  type        = string
  default     = null
}

variable "use_oidc" {
  description = "Use workload identity federation/OIDC. True in Azure DevOps, false for local az login."
  type        = bool
  default     = false
}

variable "prefix" {
  description = "Short project prefix."
  type        = string
  default     = "mdm"
}

variable "environment" {
  description = "Environment code."
  type        = string
  default     = "dev"
}

variable "location" {
  description = "Azure region."
  type        = string
  default     = "francecentral"
}

variable "tags" {
  description = "Common tags."
  type        = map(string)
  default = {
    workload  = "fabric-platform"
    managedBy = "terraform"
  }
}

variable "create_entra_groups" {
  description = "Create standard Entra groups. If false, provide existing group object ids."
  type        = bool
  default     = true
}

variable "existing_group_object_ids" {
  description = "Existing Entra group object ids when create_entra_groups=false."
  type = object({
    platform_admins        = optional(string)
    workspace_admins       = optional(string)
    workspace_contributors = optional(string)
    workspace_viewers      = optional(string)
    adls_data_engineers    = optional(string)
    azdo_iac_deployers     = optional(string)
  })
  default = {}
}

variable "fabric_capacity_sku" {
  description = "Fabric F SKU. Example: F2, F4, F8."
  type        = string
  default     = "F2"
}

variable "fabric_workspace_name" {
  description = "Fabric workspace display name."
  type        = string
  default     = null
}

variable "enable_fabric_git" {
  description = "Connect Fabric workspace to Azure DevOps Git."
  type        = bool
  default     = true
}

variable "azdo_git" {
  description = "Azure DevOps Git settings for Fabric workspace Git integration."
  type = object({
    organization_name = string
    project_name      = string
    repository_name   = string
    branch_name       = string
    directory_name    = optional(string, "/")
    connection_id     = optional(string)
    credentials_source = optional(string, "Automatic")
  })
  default = {
    organization_name  = "CHANGE_ME_ORG"
    project_name       = "CHANGE_ME_PROJECT"
    repository_name    = "CHANGE_ME_REPO"
    branch_name        = "main"
    directory_name     = "/fabric/dev"
    credentials_source = "Automatic"
  }
}
