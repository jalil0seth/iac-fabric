subscription_id = "00000000-0000-0000-0000-000000000000"
tenant_id       = "00000000-0000-0000-0000-000000000000"

prefix      = "mdm"
environment = "dev"
location    = "francecentral"

use_oidc  = true
client_id = null

fabric_capacity_sku  = "F2"
fabric_workspace_name = "ws-mdm-dev-fabric"
create_entra_groups = true

enable_fabric_git = true
azdo_git = {
  organization_name  = "CHANGE_ME_ORG"
  project_name       = "CHANGE_ME_PROJECT"
  repository_name    = "CHANGE_ME_REPO"
  branch_name        = "main"
  directory_name     = "/fabric/dev"
  credentials_source = "Automatic"
}

tags = {
  workload  = "fabric-platform"
  env       = "dev"
  managedBy = "terraform"
}
