param(
  [Parameter(Mandatory=$true)][string]$WorkspaceName
)

$ErrorActionPreference = 'Stop'
$token = az account get-access-token --resource https://api.fabric.microsoft.com --query accessToken -o tsv
$headers = @{ Authorization = "Bearer $token"; 'Content-Type' = 'application/json' }
$workspaces = Invoke-RestMethod -Method GET -Uri 'https://api.fabric.microsoft.com/v1/workspaces' -Headers $headers
$workspace = $workspaces.value | Where-Object { $_.displayName -eq $WorkspaceName } | Select-Object -First 1

if (-not $workspace) {
  throw "Workspace not found: $WorkspaceName"
}

Write-Host "Workspace found: $($workspace.displayName) / $($workspace.id)"
$roles = Invoke-RestMethod -Method GET -Uri "https://api.fabric.microsoft.com/v1/workspaces/$($workspace.id)/roleAssignments" -Headers $headers
$roles.value | Format-Table role, @{Label='PrincipalId';Expression={$_.principal.id}}, @{Label='Type';Expression={$_.principal.type}}
