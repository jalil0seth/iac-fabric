# Projet Terraform - Azure Landing Zone + Microsoft Fabric Provider

## Objectif

Ce projet gère dans Terraform :

- Resource Group.
- ADLS Gen2.
- Containers/layers : landing, bronze, silver, gold, logs, archive.
- Key Vault.
- User Assigned Managed Identity.
- Groupes Entra ID optionnels via provider `azuread`.
- Azure RBAC sur ADLS.
- Fabric Capacity via `azurerm_fabric_capacity`.
- Fabric Workspace via provider `microsoft/fabric`.
- Rôles Fabric workspace via `fabric_workspace_role_assignment`.
- Connexion Azure DevOps Git via `fabric_workspace_git`.

## Déploiement local

```bash
az login
az account set --subscription <subscription-id>
cd terraform
terraform init
terraform fmt -recursive
terraform validate
terraform plan -var-file="terraform.tfvars"
terraform apply -var-file="terraform.tfvars"
```

## Déploiement Azure DevOps

Utiliser `pipelines/azure-pipelines-terraform.yml`.

## Notes importantes

- Le provider `microsoft/fabric` nécessite Terraform >= 1.8.
- Certaines fonctionnalités Fabric/Git restent sensibles au type d'identité et à la configuration tenant. Si la connexion Git échoue avec service principal, utiliser `git_credentials.source = ConfiguredConnection` et fournir un `connection_id` Fabric.
- Les workspaces Fabric et les rôles peuvent être gérés directement en Terraform, ce qui rend cette solution plus cohérente pour l'IaC de bout en bout.
