# Pré-requis Azure DevOps Service Connection

## Recommandation

Utiliser une Azure Resource Manager service connection avec **Workload Identity Federation** au lieu d'un secret client.

## Pourquoi

- Pas de secret stocké dans Azure DevOps.
- Moins de rotation manuelle.
- Sécurité meilleure pour les pipelines IaC.

## Étapes haut niveau

1. Azure DevOps > Project Settings > Service connections.
2. New service connection > Azure Resource Manager.
3. Workload identity federation.
4. Scope : Subscription ou Resource Group selon le niveau d'automatisation.
5. Donner à l'identité les rôles Azure nécessaires :
   - Contributor sur le Resource Group cible, ou rôle custom.
   - User Access Administrator si le pipeline doit créer des role assignments Azure RBAC.
   - Storage Blob Data Contributor si le pipeline doit écrire dans ADLS.
6. Côté Fabric, ajouter l'identité comme Admin/Contributor de la capacity ou du workspace selon le besoin.

## Variables communes attendues par les pipelines

- `AZURE_SERVICE_CONNECTION`
- `AZURE_SUBSCRIPTION_ID`
- `AZURE_TENANT_ID`
- `ENVIRONMENT`
- `LOCATION`
- `PREFIX`
